</div><!-- am-pagebody -->

<script src="<?= base_url('assets/lib/jquery/jquery.js') ?>"></script>
<script src="<?= base_url('assets/lib/popper.js/popper.js') ?>"></script>
<script src="<?= base_url('assets/lib/bootstrap/bootstrap.js') ?>"></script>

</body>

</html>