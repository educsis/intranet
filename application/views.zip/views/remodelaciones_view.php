<style>
  table {
    font-size: 11px;
  }

  table.dataTable tbody th,
  table.dataTable tbody td {
    padding: 5px;
  }
</style>
<div class="row row-sm mg-t-20">
  <div class="col-xl-12 mg-t-25 mg-xl-t-0">
    <div class="card pd-10 pd-sm-10 form-layout form-layout-5">
      <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Solicitudes pendientes</h6>
      <div class="table-wrapper">
        <table id="datatable2" class="table table-condensed table-bordered display table-dark responsive nowrap">
          <thead>
            <tr>
              <th></th>
              <th>Oficina</th>
              <th style="width: 90px;">Fecha <br> Inicio</th>
              <th style="width: 90px;">Fecha <br> Fin</th>
              <th style="width: 60px;">Torre</th>
              <th style="width: 60px;">Oficina</th>
              <th style="width: 40px;">Desc.</th>
              <th style="width: 60px;">Estado</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php
            foreach ($solicitudes as $s) {
              if ($s['status_remodelacion'] == 0) {
                $fechainicio = date('d-m-Y', strtotime($s['fechainicio']));
                $fechafin = date('d-m-Y', strtotime($s['fechafin']));

                if ($s['status_remodelacion'] == 0) {
                  $estado = "PENDIENTE";
                  $estadocolor = "#ffc14d";
                } elseif ($s['status_remodelacion'] == 1) {
                  $estado = "APROBADO";
                  $estadocolor = "#00b300";
                } elseif ($s['status_remodelacion'] == 2) {
                  $estado = "DENEGADO";
                  $estadocolor = "#ff0000";
                }
            ?>
                <tr>
                  <td style="width:30px; text-align: center;"><a target="_blank" href="<?= base_url('solicitudes/solicitud_remodelaciones/' . $s['id']) ?>" class="btn btn-sm btn-default"><i class="fa fa-link"></i></a></td>
                  <td style="padding-top: 15px;"><?= $s['nombre_oficina'] ?></td>
                  <td style="text-align: center; padding-top: 15px;"><?= $fechainicio ?></td>
                  <td style="text-align: center; padding-top: 15px;"><?= $fechafin ?></td>
                  <td style="text-align: center; padding-top: 15px;"><?= $s['torre'] ?></td>
                  <td style="text-align: center; padding-top: 15px;"><?= $s['oficina'] ?></td>
                  <td style="width: 40px; text-align: center;">
                    <a href="javascript:void(0);" class="btn btn-primary btn-icon rounded-circle mg-r-5" data-container="body" data-toggle="popover" data-popover-color="default" data-placement="left" title="Descripción" data-content="<?= $s['descripcion'] ?>">
                      <div>
                        <i class="fa fa-info"></i>
                      </div>
                    </a>
                  </td>
                  <td style="text-align: center; background-color: <?= $estadocolor ?>; color: #fff; padding-top: 15px;"><?= $estado ?></td>
                  <td style="width: 100px; text-align: center;">
                    <!-- <a href="" class="btn btn-sm btn-success" data-toggle="modal" data-type="aprobado" data-titulo="Aceptar Solicitud" data-ids="<?= $s['id'] ?>" data-target="#explicacionmodal"><i class="fa fa-check"></i></a>                     -->
                    <form method="POST" action="<?= base_url('remodelaciones/estatus_change_remodelacion') ?>">
                      <input type="hidden" name="ids" value="<?= $s['id'] ?>">
                      <button style="cursor: pointer;" type="submit" name="aprobar_remodelacion" class="btn btn-sm btn-success"><i class="fa fa-check"></i></button>
                      <a href="" class="btn btn-sm btn-danger" data-toggle="modal" data-type="negado" data-titulo="Negar Solicitud" data-ids="<?= $s['id'] ?>" data-target="#explicacionmodal"><i class="fa fa-times"></i></a>
                    </form>
                  </td>
                </tr>
                </tr>
            <?php }
            } ?>
          </tbody>
        </table>
      </div><!-- table-wrapper -->
    </div><!-- card -->
  </div><!-- col-6 -->
</div>

<div class="row row-sm mg-t-20">
  <div class="col-xl-12 mg-t-25 mg-xl-t-0">
    <div class="card pd-10 pd-sm-10 form-layout form-layout-5">
      <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Solicitudes aprobadas</h6>
      <div class="table-wrapper">
        <table id="datatable3" class="table table-condensed table-bordered display table-dark responsive nowrap">
          <thead>
            <tr>
              <th></th>
              <th>Oficina</th>
              <th style="width: 90px;">Fecha <br> Inicio</th>
              <th style="width: 90px;">Fecha <br> Fin</th>
              <th style="width: 60px;">Torre</th>
              <th style="width: 60px;">Oficina</th>
              <th style="width: 40px;">Desc.</th>
              <th style="width: 60px;">Estado</th>
            </tr>
          </thead>
          <tbody>
            <?php
            foreach ($solicitudes as $s) {
              if ($s['status_remodelacion'] == 1) {
                $fechainicio = date('d-m-Y', strtotime($s['fechainicio']));
                $fechafin = date('d-m-Y', strtotime($s['fechafin']));

                if ($s['status_remodelacion'] == 0) {
                  $estado = "PENDIENTE";
                  $estadocolor = "#ffc14d";
                } elseif ($s['status_remodelacion'] == 1) {
                  $estado = "APROBADO";
                  $estadocolor = "#00b300";
                } elseif ($s['status_remodelacion'] == 2) {
                  $estado = "DENEGADO";
                  $estadocolor = "#ff0000";
                }
            ?>
                <tr>
                  <td style="width:30px; text-align: center;"><a target="_blank" href="<?= base_url('solicitudes/solicitud_remodelaciones/' . $s['id']) ?>" class="btn btn-sm btn-default"><i class="fa fa-link"></i></a></td>
                  <td style="padding-top: 15px;"><?= $s['nombre_oficina'] ?></td>
                  <td style="text-align: center; padding-top: 15px;"><?= $fechainicio ?></td>
                  <td style="text-align: center; padding-top: 15px;"><?= $fechafin ?></td>
                  <td style="text-align: center; padding-top: 15px;"><?= $s['torre'] ?></td>
                  <td style="text-align: center; padding-top: 15px;"><?= $s['oficina'] ?></td>
                  <td style="width: 40px; text-align: center;">
                    <a href="javascript:void(0);" class="btn btn-primary btn-icon rounded-circle mg-r-5" data-container="body" data-toggle="popover" data-popover-color="default" data-placement="left" title="Descripción" data-content="<?= $s['descripcion'] ?>">
                      <div>
                        <i class="fa fa-info"></i>
                      </div>
                    </a>
                  </td>
                  <td style="text-align: center; background-color: <?= $estadocolor ?>; color: #fff; padding-top: 15px;"><?= $estado ?></td>
                </tr>
                </tr>
            <?php }
            } ?>
          </tbody>
        </table>
      </div><!-- table-wrapper -->
    </div><!-- card -->
  </div><!-- col-6 -->
</div>

<div class="row row-sm mg-t-20">
  <div class="col-xl-12 mg-t-25 mg-xl-t-0">
    <div class="card pd-10 pd-sm-10 form-layout form-layout-5">
      <h6 class="tx-gray-800 tx-uppercase tx-bold tx-14 mg-b-10">Solicitudes denegadas</h6>
      <div class="table-wrapper">
        <table id="datatable4" class="table table-condensed table-bordered display table-dark responsive nowrap">
          <thead>
            <tr>
              <th></th>
              <th>Oficina</th>
              <th style="width: 90px;">Fecha <br> Inicio</th>
              <th style="width: 90px;">Fecha <br> Fin</th>
              <th style="width: 60px;">Torre</th>
              <th style="width: 60px;">Oficina</th>
              <th style="width: 40px;">Desc.</th>
              <th style="width: 60px;">Estado</th>
            </tr>
          </thead>
          <tbody>
            <?php
            foreach ($solicitudes as $s) {
              if ($s['status_remodelacion'] == 2) {
                $fechainicio = date('d-m-Y', strtotime($s['fechainicio']));
                $fechafin = date('d-m-Y', strtotime($s['fechafin']));

                if ($s['status_remodelacion'] == 0) {
                  $estado = "PENDIENTE";
                  $estadocolor = "#ffc14d";
                } elseif ($s['status_remodelacion'] == 1) {
                  $estado = "APROBADO";
                  $estadocolor = "#00b300";
                } elseif ($s['status_remodelacion'] == 2) {
                  $estado = "DENEGADO";
                  $estadocolor = "#ff0000";
                }
            ?>
                <tr>
                  <td style="width:30px; text-align: center;"><a target="_blank" href="<?= base_url('solicitudes/solicitud_remodelaciones/' . $s['id']) ?>" class="btn btn-sm btn-default"><i class="fa fa-link"></i></a></td>
                  <td style="padding-top: 15px;"><?= $s['nombre_oficina'] ?></td>
                  <td style="text-align: center; padding-top: 15px;"><?= $fechainicio ?></td>
                  <td style="text-align: center; padding-top: 15px;"><?= $fechafin ?></td>
                  <td style="text-align: center; padding-top: 15px;"><?= $s['torre'] ?></td>
                  <td style="text-align: center; padding-top: 15px;"><?= $s['oficina'] ?></td>
                  <td style="width: 40px; text-align: center;">
                    <a href="javascript:void(0);" class="btn btn-primary btn-icon rounded-circle mg-r-5" data-container="body" data-toggle="popover" data-popover-color="default" data-placement="left" title="Descripción" data-content="<?= $s['descripcion'] ?>">
                      <div>
                        <i class="fa fa-info"></i>
                      </div>
                    </a>
                  </td>
                  <td style="text-align: center; background-color: <?= $estadocolor ?>; color: #fff; padding-top: 15px;"><?= $estado ?></td>
                </tr>
                </tr>
            <?php }
            } ?>
          </tbody>
        </table>
      </div><!-- table-wrapper -->
    </div><!-- card -->
  </div><!-- col-6 -->
</div>

<div id="explicacionmodal" class="modal fade">
  <div class="modal-dialog modal-md" role="document" style="width: 500px !important;">
    <div class="modal-content bd-0 tx-14">
      <div class="modal-header pd-x-20">
        <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold tituloModal"></h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method="POST" action="<?= base_url('remodelaciones/estatus_change_remodelacion') ?>">
        <input type="hidden" class="ids" name="ids">
        <div class="modal-body pd-20">
          <div class="row">
            <div class="col-md-12 form-group">
              <label>Razón</label>
              <textarea class="form-control larazon" name="razon" required="true" autocomplete="off"></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer justify-content-center">
          <button type="submit" name="negar_remodelacion" class="btn btn-info pd-x-20 submitbtn">Enviar</button>
          <button type="button" class="closerazon btn btn-secondary pd-x-20" data-dismiss="modal">Cerrar</button>
        </div>
      </form>
    </div>
  </div>
</div>
